# Nokia-light-check-loop
This is an expect script I wrote when I had 5 minutes while waiting for splicers to find their bad splice and they kept asking me to check light on a teams call.
