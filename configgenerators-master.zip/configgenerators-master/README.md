######################
#### # Tsali
#### # Aded to GITHUB 2019/09/19
#### # UPDATED 2017/03/08
#### # Original creation is sometime in 2012
#### # Config Generators
######################

This is a collection of a couple HTML based configuration generators for various equipment my employer at the time had.
I removed a lot of stuff that was my company specific, so some things may need to be modified to meet your needs

To install
1. Log into the server you're installing it in
2. git clone https://github.com/tsali/configgenerators.git
3. cd into the configgenerators directroy
4. edit the files as you need for your gear
5. move into a webserver, or retain locally, however you wish to use it

For the copy/paste inclined:

```
git clone https://github.com/tsali/configgenerators.git && cd configgenerators && ls -lt
```
